package Domain.Items.Consumiveis;

import Domain.Items.ItemHeroi;

import java.util.ArrayList;

public class Consumivel extends ItemHeroi {


    public Consumivel(String nome, int preco) {
        super(nome, preco);
    }


}
