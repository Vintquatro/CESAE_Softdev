package Controllers.Ataques;

import Domain.Entidades.NPC;

public interface EstrategiaAtaque {

    void ataquePai (NPC npc);
}
