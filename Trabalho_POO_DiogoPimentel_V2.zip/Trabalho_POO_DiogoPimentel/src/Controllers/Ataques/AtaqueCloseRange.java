package Controllers.Ataques;

import Domain.Entidades.NPC;

public class AtaqueCloseRange implements EstrategiaAtaque {
    @Override
    public void ataquePai(NPC npc) {

    }
}
