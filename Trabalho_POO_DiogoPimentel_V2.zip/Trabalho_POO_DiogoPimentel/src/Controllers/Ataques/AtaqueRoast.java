package Controllers.Ataques;

import Domain.Entidades.NPC;

public class AtaqueRoast implements EstrategiaAtaque {
    @Override
    public void ataquePai(NPC npc) {

    }
}
